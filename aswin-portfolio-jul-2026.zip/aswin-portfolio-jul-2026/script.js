document.addEventListener('DOMContentLoaded', () => {

  /* ==========================================
     1. MOBILE MENU NAVIGATION
     ========================================== */
  const menuBtn = document.getElementById('menuBtn');
  const navLinks = document.getElementById('navLinks');
  const navItems = document.querySelectorAll('.nav-item');

  menuBtn.addEventListener('click', () => {
    menuBtn.classList.toggle('open');
    navLinks.classList.toggle('open');
  });

  navItems.forEach(item => {
    item.addEventListener('click', () => {
      menuBtn.classList.remove('open');
      navLinks.classList.remove('open');
    });
  });


  /* ==========================================
     2. TYPEWRITER EFFECT
     ========================================== */
  const typingSpan = document.querySelector('.typing-text');
  const occupations = ['Junior Web Developer.', 'Data Analyst.', 'UI/UX Designer.'];
  let currentWordIndex = 0;
  let currentCharIndex = 0;
  let isDeleting = false;
  let typingSpeed = 100;

  function type() {
    const currentWord = occupations[currentWordIndex];
    
    if (isDeleting) {
      typingSpan.textContent = currentWord.substring(0, currentCharIndex - 1);
      currentCharIndex--;
      typingSpeed = 40; // Deleting is faster
    } else {
      typingSpan.textContent = currentWord.substring(0, currentCharIndex + 1);
      currentCharIndex++;
      typingSpeed = 100; // Natural typing speed
    }

    if (!isDeleting && currentCharIndex === currentWord.length) {
      isDeleting = true;
      typingSpeed = 1800; // Pause at end of word
    } else if (isDeleting && currentCharIndex === 0) {
      isDeleting = false;
      currentWordIndex = (currentWordIndex + 1) % occupations.length;
      typingSpeed = 400; // Pause before typing next word
    }

    setTimeout(type, typingSpeed);
  }

  if (typingSpan) {
    setTimeout(type, 1000);
  }


  /* ==========================================
     3. SCROLL REVEAL & NAV ACTIVE LINKING
     ========================================== */
  const revealElements = document.querySelectorAll('.reveal');
  const sections = document.querySelectorAll('section');

  const revealObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('active');
        observer.unobserve(entry.target);
      }
    });
  }, {
    threshold: 0.1,
    rootMargin: '0px 0px -40px 0px'
  });

  revealElements.forEach(element => {
    revealObserver.observe(element);
  });

  // Track active section and update nav elements
  const sectionObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const id = entry.target.getAttribute('id');
        navItems.forEach(item => {
          if (item.getAttribute('href') === `#${id}` || (id === 'home' && item.getAttribute('href') === '#')) {
            item.classList.add('active');
          } else {
            item.classList.remove('active');
          }
        });
      }
    });
  }, {
    threshold: 0.3
  });

  sections.forEach(section => {
    sectionObserver.observe(section);
  });


  /* ==========================================
     4. SKILLS CATEGORY TAB SWITCHER
     ========================================== */
  const tabBtns = document.querySelectorAll('.tab-btn');
  const tabPanels = document.querySelectorAll('.tab-panel');

  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      // Toggle active states on button tab selectors
      tabBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      // Swap displayed panel content
      const selectedTabId = btn.getAttribute('data-tab');
      tabPanels.forEach(panel => {
        if (panel.getAttribute('id') === selectedTabId) {
          panel.classList.add('active');
        } else {
          panel.classList.remove('active');
        }
      });
    });
  });


  /* ==========================================
     5. PROJECTS PORTFOLIO FILTER
     ========================================== */
  const filterBtns = document.querySelectorAll('.filter-btn');
  const projectCards = document.querySelectorAll('.project-card');

  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const filterValue = btn.getAttribute('data-filter');

      projectCards.forEach(card => {
        const category = card.getAttribute('data-category');
        
        if (filterValue === 'all' || category === filterValue) {
          card.style.display = 'flex';
          setTimeout(() => {
            card.style.opacity = '1';
            card.style.transform = 'scale(1)';
          }, 50);
        } else {
          card.style.opacity = '0';
          card.style.transform = 'scale(0.95)';
          setTimeout(() => {
            card.style.display = 'none';
          }, 300);
        }
      });
    });
  });


  /* ==========================================
     6. CONTACT FORM SUBMISSION
     ========================================== */
  const contactForm = document.getElementById('contactForm');
  const formStatus = document.getElementById('formStatus');
  const submitBtn = document.getElementById('submitBtn');

  if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      
      const inputName = document.getElementById('name').value;
      const inputEmail = document.getElementById('email').value;
      const inputMessage = document.getElementById('message').value;

      // Visual feedback loading state
      const originalBtnText = submitBtn.innerHTML;
      submitBtn.disabled = true;
      submitBtn.innerHTML = 'Routing to Gmail...';

      // Build pre-composed Gmail compose URL
      const subject = encodeURIComponent(`Portfolio Inquiry from ${inputName}`);
      const body = encodeURIComponent(
        `Name: ${inputName}\n` +
        `Email: ${inputEmail}\n\n` +
        `Message:\n${inputMessage}`
      );
      
      const gmailUrl = `https://mail.google.com/mail/?view=cm&fs=1&to=c.m.aswin24@gmail.com&su=${subject}&body=${body}`;

      setTimeout(() => {
        // Open the Gmail composer window tab
        window.open(gmailUrl, '_blank');

        // Show success status instructions
        formStatus.textContent = 'Gmail compose tab opened. Hit Send to deliver message to Aswin!';
        formStatus.classList.add('success');
        
        // Reset form inputs
        contactForm.reset();

        // Restore button state
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalBtnText;

        // Auto-remove success indicator after 6 seconds
        setTimeout(() => {
          formStatus.classList.remove('success');
          formStatus.textContent = '';
        }, 6000);

      }, 800);
    });
  }

});
